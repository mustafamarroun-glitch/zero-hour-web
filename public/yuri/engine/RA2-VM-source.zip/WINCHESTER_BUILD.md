Pinned RA2 VM revision: a10ac9899c258b01be1edd80492397e9de225ba5

Integration removes the separate service worker and unlicensed menu plates, uses CSS buttons and Winchester artwork. Install with pnpm 11.24.0 using pnpm install --frozen-lockfile. Run pnpm run check, then pnpm exec vite build --base ./ to reproduce runtime/. Game programs and assets are supplied separately by the player.
